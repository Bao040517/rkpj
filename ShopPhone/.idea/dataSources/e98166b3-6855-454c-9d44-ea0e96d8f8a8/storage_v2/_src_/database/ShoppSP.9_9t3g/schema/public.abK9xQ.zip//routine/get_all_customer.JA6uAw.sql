create function get_all_customer()
    returns TABLE(id integer, name character varying, phone character varying, email character varying, address character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        c.id,
        c.name,
        c.phone,
        c.email,
        c.address
    FROM customer c
    ORDER BY c.id ASC;
END;
$$;

alter function get_all_customer() owner to postgres;

