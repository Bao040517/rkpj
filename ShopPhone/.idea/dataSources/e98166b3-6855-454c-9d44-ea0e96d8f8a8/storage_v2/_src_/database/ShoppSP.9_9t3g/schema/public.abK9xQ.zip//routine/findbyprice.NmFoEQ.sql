create function findbyprice(p_price_from numeric, p_price_to numeric)
    returns TABLE(id integer, name character varying, brand character varying, price numeric, stock integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        p.id,
        p.name,
        p.brand,
        p.price,
        p.stock
    FROM production p
    WHERE (p_price_from IS NULL OR p.price >= p_price_from)
      AND (p_price_to   IS NULL OR p.price <= p_price_to)
    ORDER BY p.id ASC;
END;
$$;

alter function findbyprice(numeric, numeric) owner to postgres;

