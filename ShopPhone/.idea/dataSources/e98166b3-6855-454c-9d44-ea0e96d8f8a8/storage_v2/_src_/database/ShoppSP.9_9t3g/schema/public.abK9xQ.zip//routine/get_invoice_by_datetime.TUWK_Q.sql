create function get_invoice_by_datetime(p_date_time timestamp without time zone)
    returns TABLE(invoice_id integer, customer_id integer, customer_name character varying, created_at timestamp without time zone, total_amount numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        i.id,
        c.id,
        c.name,
        i.created_at,
        i.total_amount
    FROM customer c
    JOIN invoice i
        ON c.id = i.customer_id
    WHERE DATE(i.created_at) = DATE(p_date_time)
    ORDER BY i.id ASC;
END;
$$;

alter function get_invoice_by_datetime(timestamp) owner to postgres;

