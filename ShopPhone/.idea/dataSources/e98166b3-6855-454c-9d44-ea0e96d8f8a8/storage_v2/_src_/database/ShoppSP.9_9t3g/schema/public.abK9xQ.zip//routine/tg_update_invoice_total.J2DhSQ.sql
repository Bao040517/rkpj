create function tg_update_invoice_total() returns trigger
    language plpgsql
as
$$
BEGIN
	UPDATE invoice
	SET total_amount = (
		SELECT COALESCE(SUM(quantity * unit_price),0)
		FROM invoice_details
		WHERE invoice_id =COALESCE(NEW.invoice_id, OLD.invoice_id)
	)
	  WHERE id = COALESCE(NEW.invoice_id, OLD.invoice_id);
	  RETURN NULL;
END;
$$;

alter function tg_update_invoice_total() owner to postgres;

