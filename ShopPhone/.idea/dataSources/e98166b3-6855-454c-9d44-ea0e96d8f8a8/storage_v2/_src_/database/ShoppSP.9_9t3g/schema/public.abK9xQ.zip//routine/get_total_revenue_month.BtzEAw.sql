create function get_total_revenue_month(p_year integer)
    returns TABLE(month integer, total_revenue numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        CAST(EXTRACT(MONTH FROM i.created_at) AS INT) AS month,
        SUM(i.total_amount) AS total_revenue
    FROM invoice i
    WHERE
        EXTRACT(YEAR FROM i.created_at) = p_year
    GROUP BY EXTRACT(MONTH FROM i.created_at)
    ORDER BY month;
END;
$$;

alter function get_total_revenue_month(integer) owner to postgres;

