create procedure update_customer(IN p_id integer, IN p_name character varying, IN p_phone character varying, IN p_email character varying, IN p_address character varying)
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM customer WHERE id = p_id) THEN
        RAISE EXCEPTION 'Customer với id % không tồn tại', p_id;
    END IF;

    UPDATE customer
    SET
        name = p_name,
        phone = p_phone,
        email = p_email,
        address = p_address
    WHERE id = p_id;
END;
$$;

alter procedure update_customer(integer, varchar, varchar, varchar, varchar) owner to postgres;

