create function get_total_revenue_day(p_year integer, p_month integer)
    returns TABLE(day integer, total_revenue numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        CAST(EXTRACT(DAY FROM i.created_at) AS INT) AS day,
        SUM(i.total_amount) AS total_revenue
    FROM invoice i
    WHERE
        EXTRACT(YEAR  FROM i.created_at) = p_year
        AND EXTRACT(MONTH FROM i.created_at) = p_month
    GROUP BY EXTRACT(DAY FROM i.created_at)
    ORDER BY day;
END;
$$;

alter function get_total_revenue_day(integer, integer) owner to postgres;

