create function get_invoice_by_id(p_id integer)
    returns TABLE(id integer, customer_id integer, created_at timestamp without time zone, total_amount numeric)
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM invoice i
        WHERE i.id = p_id
    ) THEN
        RAISE EXCEPTION 'Invoice với id % không tồn tại', p_id;
        RETURN;
    END IF;

    RETURN QUERY
    SELECT
        i.id,
        i.customer_id,
        i.created_at,
        i.total_amount
    FROM invoice i
    WHERE i.id = p_id
    ORDER BY i.id ASC;
END;
$$;

alter function get_invoice_by_id(integer) owner to postgres;

