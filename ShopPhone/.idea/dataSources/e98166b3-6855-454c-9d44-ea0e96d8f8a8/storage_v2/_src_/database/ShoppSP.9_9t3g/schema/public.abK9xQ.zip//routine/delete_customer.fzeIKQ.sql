create procedure delete_customer(IN c_id integer)
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM customer WHERE id = c_id) THEN
        RAISE EXCEPTION 'Customer với id % không tồn tại', c_id;
    END IF;

    DELETE FROM customer
    WHERE id = c_id;
END;
$$;

alter procedure delete_customer(integer) owner to postgres;

