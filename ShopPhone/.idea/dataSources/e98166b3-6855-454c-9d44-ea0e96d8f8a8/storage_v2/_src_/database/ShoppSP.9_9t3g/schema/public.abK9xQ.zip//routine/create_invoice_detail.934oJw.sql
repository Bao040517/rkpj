create procedure create_invoice_detail(IN p_invoice_id integer, IN p_product_id integer, IN p_quantity integer)
    language plpgsql
as
$$
DECLARE
    v_unit_price NUMERIC(12,2);
BEGIN
    -- check invoice tồn tại
    IF NOT EXISTS (
        SELECT 1 FROM invoice WHERE id = p_invoice_id
    ) THEN
        RAISE EXCEPTION 'Invoice % không tồn tại', p_invoice_id;
    END IF;

    -- check product tồn tại
    SELECT price
    INTO v_unit_price
    FROM production
    WHERE id = p_product_id;

    IF v_unit_price IS NULL THEN
        RAISE EXCEPTION 'Product % không tồn tại', p_product_id;
    END IF;

    -- insert invoice_detail (unit_price lấy từ production)
    INSERT INTO invoice_details(invoice_id, product_id, quantity, unit_price)
    VALUES (p_invoice_id, p_product_id, p_quantity, v_unit_price);

END;
$$;

alter procedure create_invoice_detail(integer, integer, integer) owner to postgres;

