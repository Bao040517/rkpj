create function check_in(i_username character varying, i_userpassword character varying)
    returns TABLE(admin_id integer, username character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        a.id,
        a.username
    FROM admin a
    WHERE a.username = i_username
      AND a.password = i_userpassword;
END;
$$;

alter function check_in(varchar, varchar) owner to postgres;

