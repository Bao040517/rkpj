create procedure create_customer(IN c_name character varying, IN c_phone character varying, IN c_email character varying, IN c_address character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO customer(name, phone, email, address)
    VALUES (c_name, c_phone, c_email, c_address);
END;
$$;

alter procedure create_customer(varchar, varchar, varchar, varchar) owner to postgres;

