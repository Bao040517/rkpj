create function get_stock_by_product_name(p_name character varying) returns integer
    language plpgsql
as
$$
DECLARE
    total_stock INTEGER;
BEGIN
    SELECT COALESCE(p.stock, 0)
    INTO total_stock
    FROM production p
    WHERE p.name ILIKE p_name;
    RETURN total_stock;
END;
$$;

alter function get_stock_by_product_name(varchar) owner to postgres;

