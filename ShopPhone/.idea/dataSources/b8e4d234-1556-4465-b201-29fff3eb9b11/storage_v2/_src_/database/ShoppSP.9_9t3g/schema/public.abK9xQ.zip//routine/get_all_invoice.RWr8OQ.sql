create function get_all_invoice()
    returns TABLE(id integer, customer_id integer, created_at timestamp without time zone, total_amount numeric)
    language plpgsql
as
$$
BEGIN
RETURN QUERY
	SELECT 
		i.id,
		i.customer_id,
		i.created_at,
		i.total_amount
	FROM invoice i
	ORDER BY id asc;
END;
$$;

alter function get_all_invoice() owner to postgres;

