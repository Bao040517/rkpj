create function getproductbyid(productid integer)
    returns TABLE(id integer, name character varying, brand character varying, price numeric, stock integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT p.id, p.name, p.brand, p.price, p.stock
        FROM production p
        WHERE p.id = productId;
END;
$$;

alter function getproductbyid(integer) owner to postgres;

