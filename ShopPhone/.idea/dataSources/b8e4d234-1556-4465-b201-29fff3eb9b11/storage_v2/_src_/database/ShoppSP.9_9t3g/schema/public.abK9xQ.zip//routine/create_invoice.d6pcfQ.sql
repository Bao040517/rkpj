create function create_invoice(i_customer_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    v_invoice_id integer;
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM customer WHERE id = i_customer_id
    ) THEN
        RAISE EXCEPTION 'Customer với id % không tồn tại', i_customer_id;
    END IF;

    INSERT INTO invoice(customer_id, created_at, total_amount)
    VALUES (i_customer_id, CURRENT_DATE, 0)
    RETURNING id INTO v_invoice_id;

    RETURN v_invoice_id;
END;
$$;

alter function create_invoice(integer) owner to postgres;

