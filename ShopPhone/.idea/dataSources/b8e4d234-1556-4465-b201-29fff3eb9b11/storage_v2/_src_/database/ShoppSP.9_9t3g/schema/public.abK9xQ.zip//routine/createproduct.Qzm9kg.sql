create procedure createproduct(IN p_name character varying, IN p_brand character varying, IN p_price numeric, IN p_stock integer)
    language plpgsql
as
$$
    BEGIN
        INSERT INTO production(name, brand, price, stock)
        VALUES (p_name,p_brand,p_price,p_stock);
    END;
    $$;

alter procedure createproduct(varchar, varchar, numeric, integer) owner to postgres;

