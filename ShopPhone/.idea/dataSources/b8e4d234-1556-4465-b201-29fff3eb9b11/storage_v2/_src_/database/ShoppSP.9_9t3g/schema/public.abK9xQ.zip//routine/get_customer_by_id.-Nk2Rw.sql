create function get_customer_by_id(p_customer_id integer)
    returns TABLE(id integer, customer_name character varying, phone character varying, email character varying, address character varying)
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM customer c
        WHERE c.id = p_customer_id
    ) THEN
        RAISE EXCEPTION 'Customer với id % không tồn tại', p_customer_id;
    END IF;

    RETURN QUERY
    SELECT
        c.id,
        c.name AS customer_name,
        c.phone,
        c.email,
        c.address
    FROM customer c
    WHERE c.id = p_customer_id;
END;
$$;

alter function get_customer_by_id(integer) owner to postgres;

