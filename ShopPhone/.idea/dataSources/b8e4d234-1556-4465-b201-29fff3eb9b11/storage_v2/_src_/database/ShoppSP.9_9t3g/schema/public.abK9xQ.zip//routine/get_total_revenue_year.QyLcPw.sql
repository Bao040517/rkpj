create function get_total_revenue_year()
    returns TABLE(year integer, total_revenue numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        CAST(EXTRACT(YEAR FROM i.created_at) AS INT) AS year,
        SUM(i.total_amount) AS total_revenue
    FROM invoice i
    GROUP BY EXTRACT(YEAR FROM i.created_at)
    ORDER BY year;
END;
$$;

alter function get_total_revenue_year() owner to postgres;

