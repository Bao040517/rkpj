create function get_invoice_by_customer_name(p_customer_name character varying)
    returns TABLE(invoice_id integer, customer_name character varying, created_at timestamp without time zone, total_amount numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        i.id AS invoice_id,
        c.name AS customer_name,
		d.id,
        i.created_at,
        i.total_amount
    FROM customer c
    INNER JOIN invoice i
    ON c.id = i.customer_id
    WHERE c.name ILIKE CONCAT('%', p_customer_name, '%')
    ORDER BY i.id ASC;
END;
$$;

alter function get_invoice_by_customer_name(varchar) owner to postgres;

