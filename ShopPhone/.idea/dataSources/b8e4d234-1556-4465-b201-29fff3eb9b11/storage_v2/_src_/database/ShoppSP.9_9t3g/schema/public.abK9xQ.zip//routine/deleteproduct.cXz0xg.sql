create procedure deleteproduct(IN p_id integer)
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM production WHERE id = p_id) THEN
        RAISE EXCEPTION 'Không tồn tại sản phẩm id = %', p_id;
    END IF;

    DELETE FROM production
    WHERE id = p_id;
END;
$$;

alter procedure deleteproduct(integer) owner to postgres;

